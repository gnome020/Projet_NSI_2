Cet projet est pour le projet en fin d'année de NSI. 
Le but est de faire un jeu mulitijouer action jouable sur un réseau local en python. 
On utilise le module pygame pour faire le jeu et le module sockets pour faire le réseau.

STARFIGHT : Le jeu que nous avons envisagé de faire.
Un maximum de 4 joueurs s'affontent pour ramasser le maximum de d'étoiles ou "Stars" sur un map. Les joueurs pourrons s'intéragir entre elles de plusieurs façons.
