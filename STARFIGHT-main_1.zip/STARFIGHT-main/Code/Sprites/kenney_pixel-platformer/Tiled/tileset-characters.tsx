<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="tileset-characters" tilewidth="24" tileheight="24" tilecount="27" columns="9">
 <tileoffset x="-3" y="0"/>
 <image source="../Tilemap/tilemap-characters_packed.png" width="216" height="72"/>
</tileset>
