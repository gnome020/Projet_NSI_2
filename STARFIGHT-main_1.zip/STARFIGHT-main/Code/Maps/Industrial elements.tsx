<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Industrial elements" tilewidth="18" tileheight="18" tilecount="112" columns="16">
 <image source="../Sprites/kenney_pixel-platformer-industrial-expansion/Tilemap/tilemap_packed.png" width="288" height="126"/>
</tileset>
