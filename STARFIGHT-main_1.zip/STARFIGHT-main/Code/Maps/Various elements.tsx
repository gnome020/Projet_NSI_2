<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Various elements" tilewidth="16" tileheight="16" tilecount="3705" columns="57">
 <image source="../Sprites/coins-chests-etc-2-0.png" width="912" height="1040"/>
</tileset>
