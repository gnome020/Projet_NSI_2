<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Base elements" tilewidth="18" tileheight="18" tilecount="180" columns="20">
 <image source="../Sprites/kenney_pixel-platformer/Tilemap/tilemap_packed.png" width="360" height="162"/>
</tileset>
